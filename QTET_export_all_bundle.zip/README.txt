QTET Export All
===============

This export bundles prior generated packages, PDFs, original saved baseline dataset traces,
from-scratch QTET-native chronology sims, Echo Meridian stability outputs, and second recoil summaries.

Notes
-----
- Echo Meridian I and II are treated as public identifiers in this export.
- This bundle includes both prior packaged artifacts and the newest from-scratch internal simulation outputs.
- The original baseline dataset is included if present in the reloaded package.
